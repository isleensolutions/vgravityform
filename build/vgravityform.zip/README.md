# vgravityform
This is Gravity form developed as vtiger extension. All entries of the Gravity form will be automatically sync to vtiger and create lead.

GravityForms website http://www.gravityforms.com/

If you found any issues please send mail to info@isleen.com 
