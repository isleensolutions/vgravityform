<?php
/*+**********************************************************************************
 * The contents of this file are subject to the Isleen Solutions Pvt Ltd Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  Isleen Solutions Pvt Ltd open source	
 * The Initial Developer of the Original Code is isleen.
 * All Rights Reserved.
 ************************************************************************************/


$languageStrings = array(
	'GravityForm' => 'Gravity Form',
	'SINGLE_GravityForm' => 'Gravity Form',
	'LBL_BLOCK_GENERAL_INFORMATION' => '',
	'LBL_BLOCK_SYSTEM_INFORMATION' => '',
    'LBL_GRAVITY_FORM_FIELD_MAPPING' => 'Gravity Form Field Mapping',
    'LBL_ADD_MAPPING' => 'Add Mapping',

);

?>
